<div class="row justify-content-center">
    <div class="col-4 mt-5">
        <div class="alert alert-danger" role="alert">
            <h2>Hiba történt!</h2>
            <?= $data['error'] ?>
        </div>
    </div>
</div>

<footer class="mt-auto py-3 my-4">
        <div class="container">
            <ul class="nav justify-content-center border-bottom pb-3 mb-3">
                <li>
                    <a href="/" class="nav-link px-2 text-secondary">
                        Kezdőoldal
                    </a>
                </li>
            </ul>
            <p class="text-center text-muted">&copy; <?= date('Y') ?> Készítették: Lovas Bálint és Fekete Zoltán</p>
        </div>
    </footer>
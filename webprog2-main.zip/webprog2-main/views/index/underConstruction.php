<div class="row">
    <div class="col-12 mt-5 text-center">
        <h4>Fejlesztés alatt!</h4>
        <img src="https://upload.wikimedia.org/wikipedia/commons/f/f4/Baustelle.svg" alt="Fejlesztés alatt" class="img-fluid">
    </div>
</div>
